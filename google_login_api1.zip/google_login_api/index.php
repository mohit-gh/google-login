<?php

    require ('vendor/autoload.php');

//Google Account Credentials
    $g_client = new Google_Client();

    $g_client->setClientId("882460385672-fk2rlf8kb72gds90cu9c5j11a8kvpn0p.apps.googleusercontent.com");
    $g_client->setClientSecret("dAFhYi_p67KDOgYuW0KfnF0f");
    $g_client->setRedirectUri("http://localhost/google_login_api/");
    $g_client->setScopes("email");

//Create the URL
    $auth_url = $g_client->createAuthUrl();
    echo "<a href='$auth_url'>Login Through Google</a>";

//Get the Authorization code
    $code = isset($_GET['code']) ? $_GET['code'] : NULL;
    //var_dump($code);

//Get Access Token
    if(isset($code)) {
        try {
            $token = $g_client->fetchAccessTokenWithAuthCode($code);
            $g_client->setAccessToken($token);
        }catch(Exception $e) {
            echo $e->getMessage();
        }

        try{
            $pay_load = $g_client->verifyIdToken();
        }catch(Exception $e) {
            echo $e->getMessage();
        }
    } else {
        $pay_load = null;
    }

    if(isset($pay_load)) {
        echo $pay_load['email'];
    }
?>