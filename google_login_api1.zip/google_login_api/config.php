<?php
session_start();

//Include Google client library 
include_once 'src/Google_Client.php';
include_once 'src/contrib/Google_Oauth2Service.php';

/*
 * Configuration and setup Google API
 */
$clientId = '882460385672-fk2rlf8kb72gds90cu9c5j11a8kvpn0p.apps.googleusercontent.com';
$clientSecret = 'dAFhYi_p67KDOgYuW0KfnF0f';
$redirectURL = 'http://localhost/google_login_api/';

//Call Google API
$gClient = new Google_Client();
$gClient->setApplicationName('Login to CodexWorld.com');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>